=== custom-post-feed-plugin ===
Contributors:R.Praveen Kumar
Donate link: http://webdesigingcoding.wordpress.com/
Tags: feed,custom post
Requires at least: 3.0
Tested up to: 3.0.1
Stable tag: 3.0

== Description ==

It Allows You to Create Feed For the custom posts which ever you created.For More Details visit http://webdesigingcoding.wordpress.com/2010/09/03/custom-post-feed-plugin/ 


== Installation ==

This section describes how to install the plugin and get it working.

1. Upload `custom-post-feed-plugin` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. For more visit http://webdesigingcoding.wordpress.com/2010/09/03/custom-post-feed-plugin/

== Frequently Asked Questions ==
For more visit http://webdesigingcoding.wordpress.com/2010/09/03/custom-post-feed-plugin/


== Screenshots ==
For more visit http://webdesigingcoding.wordpress.com/2010/09/03/custom-post-feed-plugin/


== Changelog ==

= 1.0 =
This is the First Version have to change it to User Compatibility

== Upgrade Notice ==

= 1.0 =
There is no upgrage Available


